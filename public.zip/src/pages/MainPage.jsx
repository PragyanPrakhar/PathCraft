import React from "react";
import { useState } from "react";

const MainPage = () => {
    return (
        <div className="bg-black h-screen w-screen text-white">
            <div className="m-2">
                <h1 className="text-2xl">Mention Your Skill Below !</h1>
            </div>
        </div>
    );
};

export default MainPage;
